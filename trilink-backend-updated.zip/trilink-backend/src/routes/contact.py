from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

contact_bp = Blueprint('contact', __name__)

def send_email_notification(form_data):
    """Send email notification when contact form is submitted"""
    try:
        # Email configuration - using Zoho SMTP
        smtp_server = "smtp.zoho.com"
        smtp_port = 587
        
        # These should be configured with your actual Zoho email credentials
        # Use one of your existing Zoho email accounts as the sender
        sender_email = os.getenv('SENDER_EMAIL', 'info@trilinktechnology.com')
        sender_password = os.getenv('SENDER_PASSWORD', 'your-zoho-password')
        recipient_emails = [
            'malzalam@trilinktechnology.com',
            'melouassi@trilinktechnology.com', 
            'info@trilinktechnology.com'
        ]
        
        # Create message
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = ', '.join(recipient_emails)
        msg['Subject'] = f"New Contact Form Submission from {form_data['name']}"
        
        # Email body
        body = f"""
        New contact form submission from TriLink Technology website:
        
        Name: {form_data['name']}
        Email: {form_data['email']}
        Company: {form_data.get('company', 'Not provided')}
        Phone: {form_data.get('phone', 'Not provided')}
        
        Message:
        {form_data['message']}
        
        ---
        This email was automatically generated from the TriLink Technology contact form.
        """
        
        msg.attach(MIMEText(body, 'plain'))
        
        # Send email to all recipients
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)
        text = msg.as_string()
        server.sendmail(sender_email, recipient_emails, text)
        server.quit()
        
        return True
        
    except Exception as e:
        print(f"Error sending email: {str(e)}")
        return False

@contact_bp.route('/contact', methods=['POST'])
@cross_origin()
def submit_contact_form():
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('name') or not data.get('email') or not data.get('message'):
            return jsonify({'error': 'Name, email, and message are required'}), 400
        
        # Extract form data
        form_data = {
            'name': data.get('name'),
            'email': data.get('email'),
            'company': data.get('company', ''),
            'phone': data.get('phone', ''),
            'message': data.get('message')
        }
        
        # Log the contact form submission
        print(f"Contact form submission:")
        print(f"Name: {form_data['name']}")
        print(f"Email: {form_data['email']}")
        print(f"Company: {form_data['company']}")
        print(f"Phone: {form_data['phone']}")
        print(f"Message: {form_data['message']}")
        
        # Send email notification
        email_sent = send_email_notification(form_data)
        
        if email_sent:
            print("Email notification sent successfully")
        else:
            print("Failed to send email notification")
        
        # Return success response regardless of email status
        # (so the user doesn't see an error if email fails)
        return jsonify({
            'success': True,
            'message': 'Thank you for your inquiry! We will contact you soon.'
        }), 200
        
    except Exception as e:
        print(f"Error processing contact form: {str(e)}")
        return jsonify({'error': 'An error occurred processing your request'}), 500

